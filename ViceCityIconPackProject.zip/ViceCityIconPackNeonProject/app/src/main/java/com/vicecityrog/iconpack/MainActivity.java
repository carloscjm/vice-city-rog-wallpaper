package com.vicecityrog.iconpack;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Button;

/** Icon pack ADW/Nova com camadas: iconback, iconupon, iconmask, scale.
 *  A cobertura automatica depende do launcher ASUS. Nao altera outros apps nem o wallpaper.
 */
public class MainActivity extends Activity {
    private TextView text(String value, int size, int color) {
        TextView v = new TextView(this);
        v.setText(value);
        v.setTextSize(size);
        v.setTextColor(color);
        v.setGravity(Gravity.CENTER);
        v.setPadding(12, 15, 12, 20);
        return v;
    }
    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(17,13,35));
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setGravity(Gravity.CENTER);
        layout.setPadding(24,48,24,40);
        ImageView image = new ImageView(this);
        image.setImageResource(R.drawable.pack_preview);
        image.setAdjustViewBounds(true);
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(-1,280);
        image.setLayoutParams(ip);
        layout.addView(image);
        layout.addView(text("VICE CITY - ROSA NEON",22,0xFFE5EDFF));
        layout.addView(text("Moldura rosa neon, com detalhes em azul e roxo inspirados em Vice City.\n"
          + "Mantem o logo original nos aplicativos que o launcher consegue emoldurar.",15,0xFFD4D7E5));
        layout.addView(text("COMO APLICAR NO ASUS\n\n"
          + "1. Volte para a tela inicial.\n"
          + "2. Toque e segure em um espaco vazio.\n"
          + "3. Abra Preferencias / Pacotes de icones / Icon Pack.\n"
          + "4. Escolha 'Vice City - Rosa Neon'.\n\n"
          + "Se o pacote nao aparecer, experimente o 'ASUS Icon Pack Applyer' da Play Store.\n\n"
          + "Atencao: a moldura automatica para todos os apps depende do suporte de cada versao do launcher ASUS. As pastas tambem podem nao ser alteradas.",15,0xFFFFFFFF));
        Button go = new Button(this);
        go.setText("IR PARA TELA INICIAL");
        go.setOnClickListener(v -> { Intent home = new Intent(Intent.ACTION_MAIN);
            home.addCategory(Intent.CATEGORY_HOME); startActivity(home); });
        layout.addView(go);
        scroll.addView(layout);
        setContentView(scroll);
    }
}
