# Vice City — Moldura Rosa Neon (Icon Pack Android)

Este e um projeto Android independente do wallpaper. Ele usa a moldura rosa neon, roxo e azul criada a partir da identidade visual Vice City.

## Como funciona

- `appfilter.xml` em `assets/` e `res/xml/` contem `iconback`, `iconupon`, `iconmask` e `scale` no padrao ADW/Nova.
- `res/drawable-nodpi/` contem camadas e exemplos de icones tirados da captura de tela. Os logotipos desses exemplos foram mantidos intactos.
- As regras `item` mapeiam apenas algumas activities conhecidas; a aplicacao de moldura a todos os apps so ocorre se o launcher respeitar o fallback automatico.
- Os icones de pastas e de aplicativos nao mapeados podem permanecer sem mudancas no ASUS Launcher.
- Nenhuma permissao de acesso a contatos, arquivos ou rede e requerida.

## Compilacao

JDK 17, Android SDK 35, Gradle 8.9, Android Gradle Plugin 8.7.3.

`gradle --no-daemon :app:assembleDebug`

Resultado: `app/build/outputs/apk/debug/app-debug.apk`.

## Instalacao

`adb install -r app-debug.apk`

No ASUS Launcher, procure em Preferencias > Pacote de icones. Se nao aparecer, o app de terceiros `ASUS Icon Pack Applyer` pode ajudar (nao e garantido em todas as versoes).

## Observacao

O APK nao altera automaticamente outros aplicativos e nao pode obrigar o ASUS Launcher a aplicar bordas a todos os icones. O resultado depende de suporte do launcher. O wallpaper animado e preservado.
